### How to install

install the necessary files using `npm i` or `npm install` , doing so will ensure that all files needed are installed

### How to run 

navigate to the folder called 'candy-crush' located inside 'Candy-crush-folder' using the `cd folder-name` terminal command.
Once navigated to the desired file enter `npm start file-name` to run the project in a localhost

### Rules of the game

1. Match 3 or 4 of the candies in columns or rows to gain points.
2. Match all candies to get the target your score to match with the target score. 
3. Click the restart button to restart the game.